var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__1io3bae._.js")
R.c("server/chunks/ssr/node_modules_next_dist_0nkkbfv._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1e8ttch._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1uan58j._.js")
R.c("server/chunks/ssr/node_modules_next_dist_client_components_builtin_global-error_0q-w892.js")
R.c("server/chunks/ssr/apps_web__next-internal_server_app__global-error_page_actions_1vxuwj7.js")
R.m(42378)
module.exports=R.m(42378).exports
