var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/layout/route.js")
R.c("server/chunks/[root-of-the-server]__1o_soo6._.js")
R.c("server/chunks/[root-of-the-server]__0g_s5df._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_layout_route_actions_1t7i68j.js")
R.m(83844)
module.exports=R.m(83844).exports
