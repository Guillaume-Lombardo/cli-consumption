var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reporting/[resource]/route.js")
R.c("server/chunks/[root-of-the-server]__0c9ikya._.js")
R.c("server/chunks/[root-of-the-server]__0g_s5df._.js")
R.c("server/chunks/044u_web__next-internal_server_app_api_reporting_[resource]_route_actions_0i_7s2o.js")
R.m(76400)
module.exports=R.m(76400).exports
