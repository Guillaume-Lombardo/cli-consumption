var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reporting/export/route.js")
R.c("server/chunks/[root-of-the-server]__0w_xj5w._.js")
R.c("server/chunks/[root-of-the-server]__1sv85l5._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_reporting_export_route_actions_0nmvtq9.js")
R.m(28497)
module.exports=R.m(28497).exports
