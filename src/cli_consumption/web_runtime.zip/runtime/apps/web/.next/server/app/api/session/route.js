var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/session/route.js")
R.c("server/chunks/[externals]__0bjc7vc._.js")
R.c("server/chunks/[root-of-the-server]__1mv0cpi._.js")
R.c("server/chunks/_0ef51im._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_session_route_actions_0wvvoqb.js")
R.m(48852)
module.exports=R.m(48852).exports
