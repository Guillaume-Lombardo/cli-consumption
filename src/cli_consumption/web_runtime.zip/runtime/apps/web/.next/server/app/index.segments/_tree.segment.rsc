:HL["/_next/static/chunks/3r0_r2c7sri7u.css","style"]
:HC["/",""]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}},"staleTime":300,"buildId":"cli-consumption-dashboard"}
