module.exports=[99496,s=>{"use strict";s.s([])}];

//# sourceMappingURL=044u_web__next-internal_server_app_api_reporting_%5Bresource%5D_route_actions_0i_7s2o.js.map