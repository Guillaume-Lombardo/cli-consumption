globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/cli-consumption-dashboard/_buildManifest.js",
    "static/cli-consumption-dashboard/_ssgManifest.js",
    "static/cli-consumption-dashboard/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/1f0m_nyksetzr.js",
    "static/chunks/1rj7ns8rte9vc.js",
    "static/chunks/1bd6-d9tokmw0.js",
    "static/chunks/turbopack-19ihkw_bd7681.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
